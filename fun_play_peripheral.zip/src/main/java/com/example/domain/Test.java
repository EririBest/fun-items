package com.example.domain;

import lombok.Data;

/**
 * @author 覃汉宇
 * @date 2023/04/16/16:34
 * @brief
 */
@Data
public class Test {
    private Integer id;
    private Integer userid;
    private String uimg;
    private String uname;
    private String room;
    private Integer gid;
    private String gimg;
    private Integer newtext;
}
