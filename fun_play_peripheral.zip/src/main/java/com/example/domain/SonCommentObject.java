package com.example.domain;

import lombok.Data;

/**
 * @author 覃汉宇
 * @date 2023/05/06/12:41
 * @brief
 */
@Data
public class SonCommentObject {
    private Integer id;
    private String uimg;
    private String rname;
    private String uname;
    private String text;
}
