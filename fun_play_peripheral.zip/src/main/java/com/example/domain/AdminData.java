package com.example.domain;

import lombok.Data;

/**
 * @author 覃汉宇
 * @date 2023/05/16/20:06
 * @brief
 */
@Data
public class AdminData {
    private Integer id;
    private String name;
    private String password;
    private Integer flag;
}
